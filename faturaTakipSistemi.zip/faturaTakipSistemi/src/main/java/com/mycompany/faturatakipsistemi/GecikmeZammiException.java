package com.mycompany.faturatakipsistemi;

public class GecikmeZammiException extends Exception {
    public GecikmeZammiException(String mesaj) {
        super(mesaj);
    }
}
