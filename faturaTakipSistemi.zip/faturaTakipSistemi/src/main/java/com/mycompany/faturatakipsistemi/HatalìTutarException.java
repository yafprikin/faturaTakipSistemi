package com.mycompany.faturatakipsistemi;

public class HatalıTutarException extends Exception {
    public HatalıTutarException(String mesaj) {
        super(mesaj);
        

    
    }
}

